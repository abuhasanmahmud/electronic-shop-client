import React from "react";
import Footer from "../../sharied/Footer/Footer";
import Navbar from "../../sharied/Navbar/Navbar";
import Banner from "./Banner";
import FeatureProduct from "./FeatureProduct";

const Home = () => {
  return (
    <div>
      <div></div>
      <Navbar></Navbar>
      <Banner></Banner>
      <FeatureProduct></FeatureProduct>
      <Footer></Footer>
    </div>
  );
};

export default Home;
