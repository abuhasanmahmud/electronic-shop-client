import React from "react";

const UserProfile = () => {
  return (
    <div>
      <p>User profile</p>
    </div>
  );
};

export default UserProfile;
