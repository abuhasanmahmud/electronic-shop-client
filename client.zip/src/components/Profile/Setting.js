import React from "react";
import Footer from "../../sharied/Footer/Footer";
import Navbar from "./../../sharied/Navbar/Navbar";

const Setting = () => {
  return (
    <div>
      <Navbar></Navbar>
      <p className="my-5">User profile settings</p>
      <Footer></Footer>
    </div>
  );
};

export default Setting;
